#include"game.h"
#include "user.h"
#include"select.h"
using namespace LiuZhenCheng;
coordinate head, * body;
int length;//�ߵĳ���
Snake::Snake()
{
	head.next = NULL;
	body = NULL;
	length = 0;
}

void Snake::m_create_snake()
{
	for (int i = 0; i < 4; i++)
	{
		body = new coordinate;
		body->x = 100 + 20 * i;
		body->y = 100;
		//ͷ�巨
		body->next = head.next;//NULL
		head.next = body;
		//�����ʼ����
		m_draw_snake();
		length++;
	}
}

void Snake::m_up()
{
	head.next->y -= 20;
}

void Snake::m_down()
{
	head.next->y += 20;
}

void Snake::m_left()
{
	head.next->x -= 20;
}

void Snake::m_right()
{
	head.next->x += 20;
}

void Snake::m_change_direction()
{
	//�ı䷽��
	switch (direction)
	{
	case R:
		m_right();
		break;
	case L:
		m_left();
		break;
	case U:
		m_up();
		break;
	case D:
		m_down();
		break;
	default:
		break;
	}
}

void Snake::m_draw_snake()
{
	
	setfillcolor(RGB(255, 165, 0));//������ɫ
	fillrectangle(head.next->x, head.next->y, head.next->x + 20, head.next->y + 20);
	SetWorkingImage();//Ĭ��ֵΪ0�����Ƶ���ǰ���� 
}

void Snake::m_erase_snake()
{
	clearrectangle(body->next->x, body->next->y, body->next->x + 20, body->next->y + 20);
}

void Snake::m_snakemove()
{
	Sleep(speed);//�ٶ�
	keyboard();

	//��ԭʼ��head.next������ֵ������,������Ϊ��β�ڵ�
	int temp_x = head.next->x;
	int temp_y = head.next->y;
	//�ı䷽��
	m_change_direction();

	//����β�ڵ�ڵ���ͷ���ﵽ�ƶ���Ч��
	coordinate* temp = new coordinate;
	temp->x = temp_x;
	temp->y = temp_y;
	temp->next = head.next->next;
	head.next->next = temp;

	if (food_coord.x == head.next->x && food_coord.y == head.next->y)
	{
		setfillcolor(RGB(255, 165, 0));//������ɫ
		fillrectangle(food_coord.x, food_coord.y, food_coord.x + 20, food_coord.y + 20);
		Food food;
		food.m_create_food();
		length++;
	}
	else
	{
		m_draw_snake();//����ǰ���ĵ�һ��λ�û��Ʒ���
		body = head.next;
		while (body->next->next != NULL)
		{
			m_eat_body();
			body = body->next;
		}
		m_erase_snake();//�����β�Ľڵ�
		delete body->next;//�ͷ���β�ڵ��ڴ�
		body->next = NULL;
	}
}

void Snake::m_hit_wall()
{
	if (head.next->x <= 10 || head.next->x + 20 >= 1410 || head.next->y <= 10 || head.next->y + 20 >= 710)
	{
		system("cls");
		cout << "�û���:" << write_name << endl;
		cout << "�ߵĳ���:" << length << " M" << endl;
		//ChenGuangLI_2::term_cout();
		//LiuZhenCheng::read_file();
		game_over();
	}
}

void Snake::m_eat_body()
{
	if (
		body->next->next != NULL &&
		body->next->next->x == (head.next)->x &&
		body->next->next->y == (head.next)->y
		)
	{
		system("cls");
		cout << "�û���:" << write_name << endl;
		cout << "�ߵĳ���:" << length << " M" << endl;
		game_over();
	}
}

Snake::~Snake()
{
}
