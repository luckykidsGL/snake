#include"game.h"
#include"user.h"
using namespace LiuZhenCheng;
int main()
{
	user_interface();
	return 0;
}




