#include"game.h"
#include"user.h"
#include"select.h"
using namespace std;
using namespace ChenGuanLi;
void user_interface()
{
	while (true)
	{
		bool p = false;
		//show_choice();
		ChenGuangLI_2::Controller u;
		switch (u.m_select())
		{
			case 1:
				p = registers();
				if (p)
				{
					cout << "ע��ɹ���";
					Sleep(300);
					system("cls");
					user_interface();
				}
				else
				{
					cout << "ע��ʧ��";
					Sleep(300);
					system("cls");
					user_interface();
				}
				break;
			case 2:
				login();
				break;
			case 3:
				retrieve_password();
				break;
			case 4:
				exit(0);
				break;
			default:
				cout << "����";
				break;
		}
	}
}
	

