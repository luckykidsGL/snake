#include"game.h"
#include "user.h"
#include<algorithm>
#include"select.h"
#include<conio.h>//��ȡ������Ϣ
int direction = R;
int speed = 100;
typedef pair<string, int> pii;

void LiuZhenCheng::keyboard()
{

	if (GetAsyncKeyState(VK_OEM_PLUS))
	{
		speed -= 10;
	}
	else if (GetAsyncKeyState(VK_OEM_MINUS))
	{
		speed += 10;
	}
	else if (GetAsyncKeyState(VK_SPACE))
	{
		system("pause");
	}
	else if (GetAsyncKeyState(VK_UP) && direction != D)
	{
		direction = U;
	}
	else if (GetAsyncKeyState(VK_DOWN) && direction != U)
	{
		direction = D;
	}
	else if (GetAsyncKeyState(VK_LEFT) && direction != R)
	{
		direction = L;
	}
	else if (GetAsyncKeyState(VK_RIGHT) && direction != L)
	{
		direction = R;
	}
}


void LiuZhenCheng::game_over()
{
	//system("cls");
	LOGFONT f;
	gettextstyle(&f);                     // ��ȡ��ǰ��������
	f.lfHeight = 100;                      // ���������С
	_tcscpy_s(f.lfFaceName, _T("΢���ź�"));    // ��������Ϊ(�߰汾 VC �Ƽ�ʹ�� _tcscpy_s ����)
	f.lfQuality = ANTIALIASED_QUALITY;    // �������Ч��Ϊ�����  
	settextstyle(&f);                     // ����������ʽ
	settextcolor(RGB(255,69,0));		  // ���õ�ǰ������ɫ
	outtextxy(470, 200, _T("    ��������    "));
	outtextxy(400, 300, _T("�����л���"));
	Sleep(500);
	ranking_file();
	//cleardevice();
	closegraph(); //��ջ�ͼ����ص�ԭ������
	ChenGuangLI_2::term_cout();
	ChenGuanLi::mode_select();
}


void LiuZhenCheng::ranking_file()
{
	int write_length = length;
	ofstream outfile;
	outfile.open("ranking.txt", ios::app);
	outfile << endl << write_name << endl << write_length;
	outfile.close();
}



bool cmp(pii a, pii b)
{
	return a.second > b.second;
}


void LiuZhenCheng::read_file()
{
	//system("cls");
	map<string, int>rank;
	map<string, int>::iterator it;
	vector<pii> v_rank;
	vector<pii>::iterator v_it;
	int L[100];
	string N[100];
	string read_name;
	int read_length;
	ifstream ifile("ranking.txt");
	int i = 0;
	while (ifile.peek() != EOF)
	{
		ifile >> read_name;
		ifile >> read_length;
		L[i] = read_length, N[i] = read_name;
		rank[N[i]] = L[i];
		i++;
	}
	for (it = rank.begin(); it != rank.end(); it++)
	{
		v_rank.push_back(pii(it->first, it->second));
	}
	sort(v_rank.begin(), v_rank.end(), cmp);
	int t = 9;
	for (v_it = v_rank.begin(); v_it != v_rank.end(); v_it++)
	{
		ChenGuangLI_2::set_cursor_position(25, t);
		cout << v_it->first;
		ChenGuangLI_2::set_cursor_position(35, t);
		cout<< v_it->second;
		if (t == 19) break;
		t++;
	}
	ifile.close();
	ChenGuangLI_2::set_cursor_position(25, 4);
	cout << write_name;
	ChenGuangLI_2::set_cursor_position(35, 4);
	cout << length;
	ChenGuangLI_2::set_cursor_position(24, 30);
}



